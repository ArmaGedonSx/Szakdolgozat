# AppRTCWPF
iConfRTC Demo for WPF

Uses iConfRTC.WPF.X86 package.

For licensing of the iConfRTC SDK visit https://avspeed.github.io/

<!-- copy and paste. Modify height and width if desired. --> <a href="https://content.screencast.com/users/AVSPEEDInc.Suppo/folders/Default/media/34d75848-6afe-4dba-a280-ef465faa6fad/wpfquickdemo.gif"><img class="embeddedObject" src="https://content.screencast.com/users/AVSPEEDInc.Suppo/folders/Default/media/34d75848-6afe-4dba-a280-ef465faa6fad/wpfquickdemo.gif" width="600" height="338" border="0" /></a>